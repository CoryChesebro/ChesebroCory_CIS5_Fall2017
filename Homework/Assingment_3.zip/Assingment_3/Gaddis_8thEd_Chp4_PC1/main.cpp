
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 3 2017 8:15 PM
 * Purpose: Min/Max
 */

//System libraries
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    int num1, num2;
    
    //Process mapping from inputs to outputs
    cout<<"This program takes two numbers and tells you which is greater"<<endl;
    
    //Get numbers
    cout<<"Enter number 1: ";
    cin>>num1;
    cout<<endl;
    
    cout<<"Enter number 2: ";
    cin>>num2;
    cout<<endl;
    
    //Compare the numbers
    (num1>num2)?(cout<<num1<<" is greater than "<<num2):(cout<<num2<<" is greater"
            " than "<<num1);
    
    //Exit to function main / End program
    return 0;
}
