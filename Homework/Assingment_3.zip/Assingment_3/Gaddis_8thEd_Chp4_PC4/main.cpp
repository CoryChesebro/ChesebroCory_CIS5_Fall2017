
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 3 2017 8:45 PM
 * Purpose: Area of rectangles
 */

//System libraries
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    short width1, width2, length1, length2;
    int area1, area2;
    
    //Process mapping from inputs to outputs
    cout<<"This program gets the dimensions of two rectangles and outputs "
            "which is bigger in area"<<endl;
    
    //Get dimensions of rectangles
    cout<<"Enter the length and width of rectangle one: ";
    cin>>width1>>length1;
    cout<<endl;
    
    cout<<"Enter the length and width of rectangle two: ";
    cin>>width2>>length2;
    cout<<endl;
    
    //Find which rectangle is bigger
    area1 = length1 * width1;
    area2 = length2 * width2;
    if(!(area1 == area2)){
    (area1>area2)?(cout<<"Rectangle one is bigger with an area of "<<area1):
        (cout<<"Rectangle two is bigger with an area of "<<area2);
    }
    else{
        cout<<"The rectangles are equal in area! Area = "<<area1;
    }
    //Exit to function main / End program
    return 0;
}

