
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 3 2017 8:45 PM
 * Purpose: Mass and Weight 
 */

//System libraries
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float G = 9.8f;

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    unsigned short mass, newtons;
    
    //Process mapping from inputs to outputs
    cout<<"This program takes mass as input and tells you its weight in Newtons"
            <<endl;
    
    //Get mass of object
    cout<<"Enter the mass of the object in Kg: ";
    cin>>mass;
    cout<<endl;
    
    //Convert and output
    newtons = mass * G;//Conversion
    
    if(newtons >= 10 && newtons <= 1000){//Output has to be in range of 10 and 1000
        cout<<"The weight of the object is "<<newtons<<" N";
        
    }
    else{//Handles values outside of the the range 10 - 1000
        (newtons < 10)?(cout<<"The object is too light"<<endl):
            (cout<<"The object is too heavy"<<endl);
    }
    
    //Exit to function main / End program
    return 0;
}

