
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 11 2017 10:56 PM
 * Purpose: Color mixer
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const string RR = "Red";
const string RB = "Purple";
const string BB = "Blue";
const string BY = "Green";
const string YY = "Yellow";
const string YR = "Orange";

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    string a,b;//Holds inputs
    
    //Process mapping from inputs to outputs
    cout<<"This program will give you the secondary color that results from mixing"
            " two primary colors such as red, blue, and yellow ."<<endl;
    
    //Get colors from the user
    cout<<"Enter the primary colors you'd like to mix."<<endl;
    
    cout<<"Color 1: ";
    cin>>a;
    cout<<endl;
    
    cout<<"Color 2: ";
    cin>>b;
    cout<<endl;
    
    //Check to make sure primary colors were used
    if((a == "red" || a == "Red") || (a == "blue" || a == "Blue") || ( a == "yellow" 
            || a == "Yellow") && (b == "red" || b == "Red") || (b == "blue" || 
            b == "Blue") || ( b == "yellow" || b == "Yellow") ){
        
        if((a == "red" || a == "Red") && (b == "red" || b == "Red")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<RR<<endl;
        }
        
        if((a == "blue" || a == "Blue") && (b == "red" || b == "Red")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<RB<<endl;
        }
        
        if((a == "red" || a == "Red") && (b == "blue" || b == "Blue")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<RB<<endl;
        }
        
        if((a == "blue" || a == "Blue") && (b == "blue" || b == "Blue")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<BB<<endl;
        }
        
        if((a == "blue" || a == "Blue") && (b == "yellow" || b == "Yellow")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<BY<<endl;
        }
        
        if((a == "yellow" || a == "Yellow") && (b == "blue" || b == "Blue")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<BY<<endl;
        }
        
        if((a == "yellow" || a == "Yellow") && (b == "yellow" || b == "Yellow")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<YY<<endl;
        }
        
        if((a == "yellow" || a == "Yellow") && (b == "red" || b == "Red")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<YR<<endl;
        }
        
        if((a == "red" || a == "Red") && (b == "yellow" || b == "Yellow")){
            cout<<"When you mix "<<a<<" and "<<b<<" you get "<<YR<<endl;
        }
    }
    
    else{
        cout<<"Go back to kindergarten, those arent primary colors";
        
    }
    
    //Exit to function main / End program
    return 0;
}

