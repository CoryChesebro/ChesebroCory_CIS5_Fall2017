
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 3 2017 7:15 PM
 * Purpose: Change for a dollar game
 */

//System libraries
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float ten19 = 0.2f;
const float twent49 = 0.3f;
const float fift99 = 0.4f;
const float hundred = 0.5f;
//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    int quant;
    float total;
    
    //Process mapping from inputs to outputs
    cout<<"This program will tell you your discounted price based on quantity "
            "of items bought."<<endl;
    
    //Get quantity
    cout<<"Please enter how many products you are ordering: ";
    cin>>quant;
    cout<<endl;
    
    //Find if quantity qualifies for discount and output accordingly
    cout<<fixed<<setprecision(2);//To make number outputs money like
    total = quant * 99;//Gets total price before discount
    
    if(quant >= 100){
        total = (total * hundred);
        cout<<"Your order will cost $"<<total;
        exit(EXIT_SUCCESS);//To ensure the next if doesnt get triggered on accident
    }
    
    if(quant >= 50 && quant <= 99){
        total = (total * fift99);
        cout<<"Your order will cost $"<<total;
        exit(EXIT_FAILURE);
    }
    
    if(quant >= 20 && quant <= 49){
        total = (total * twent49);
        cout<<"Your order will cost $"<<total;
        exit(EXIT_FAILURE);
    }
    
    if(quant >= 10 && quant <= 19){
        total = (total * ten19);
        cout<<"Your total will cost $"<<total;
        exit(EXIT_FAILURE);
    }
    
    if(quant > 0 && quant < 10){
        cout<<"Your total will cost $"<<total;
        exit(EXIT_FAILURE);
    }
    
    else{
        cout<<"Please enter a valid quantity";
    }
    
    //Exit to function main / End program
    return 0;
}

