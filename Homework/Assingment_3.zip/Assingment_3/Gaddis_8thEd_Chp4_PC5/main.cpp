
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 3 2017 8:45 PM
 * Purpose: Mass and Weight 
 */

//System libraries
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const short num = 703;//Arbitrary number used to find bmi
//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float bmi;
    short weight, height;
    
    //Process mapping from inputs to outputs.
    cout<<"This program will take your height and weight and give you your BMI"
            <<endl;
    //Get height and weight
    cout<<"Please first enter your height in inches and then your weight in pounds: ";
    cin>>height>>weight;
    cout<<endl;
    
    //Calculate BMI and find if overweight or under or optimal
    bmi = (static_cast<float>(weight) * num)/(height * height);//Static cast to get answer as float
    
    cout<<fixed<<setprecision(1);//One decimal accuracy for output
    
    if(bmi >= 18.5 && bmi <= 25){
        cout<<"Your BMI is "<<bmi<<" and is the optimal range"<<endl;
    }
    else{
        (bmi < 18.5)?(cout<<"Your BMI is "<<bmi<<" and is considered underweight"<<endl):
            (cout<<"Your BMI is "<<bmi<<" and is considered overweight"<<endl);
    }
    //Exit to function main / End program
    return 0;
}

