
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 3 2017 7:15 PM
 * Purpose: Change for a dollar game
 */

//System libraries
#include <iostream>
#include <stdlib.h>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const short penny = 1;
const short nickel = 5;
const short dime = 10;
const short quarter = 25;

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    short total;
    short nPen, nNick, nDime, nQuar;
    
    //Process mapping from inputs to outputs
    cout<<"This is a game to get you to make a dollar by adding change."<<endl;
    
    //Gets amount of change from user
    cout<<"You will be asked how much of each coin you want to input, if you reach"
            " 100 you will win!"<<endl;
    
    cout<<"Enter the number of pennies: ";
    cin>>nPen;
    cout<<endl;
    if((nPen * penny) == 100){
        cout<<"You win!"<<endl;
        exit(EXIT_FAILURE);
    }
    else{
        total += (nPen * penny);
    }
    
    cout<<"Enter the number of nickels: ";
    cin>>nNick;
    cout<<endl;
    if((total += (nNick * nickel)) == 100){
        cout<<"You win!"<<endl;
        exit(EXIT_FAILURE);
    }
    else{
        total += (nNick * nickel);
    }
    
    cout<<"Enter the number of dimes: ";
    cin>>nDime;
    cout<<endl;
    if((total += (nDime * dime)) == 100){
        cout<<"You win!"<<endl;
        exit(EXIT_FAILURE);
    }
    else{
        total += (nDime * dime);
    }
    
    cout<<"Enter the number of quarters: ";
    cin>>nQuar;
    cout<<endl;
    if((total += (nQuar * quarter)) == 100){
        cout<<"You win!"<<endl;
        exit(EXIT_FAILURE);
    }
    else{
        total += (nQuar * quarter);
    }
    
    if(total > 100){
        cout<<"You went over! You did not win the game and your total was "<<total<<
                endl;
    }
    else{
        cout<<"You went under! You did not win the game and your total was "<<total<<
                endl;
    }
    
    
    
    //Exit to function main / End program
    return 0;
}

