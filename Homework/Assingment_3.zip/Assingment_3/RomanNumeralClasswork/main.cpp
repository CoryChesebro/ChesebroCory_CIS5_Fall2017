/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Convert to Roman Numerals
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const int THSND = 1000;
const int HNDRD = 100;
const int TENS = 10;
const int ONES = 1;

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main() {
    //Declare all Variables Here
    unsigned char nThsnds, nHundrds, nTens, nOnes;
    unsigned short number;
    
    //Input or initialize values Here
    cout<<"This program converts numbers to roman numerals"<<endl;
    
    cout<<"Type in a number between 1000 and 3000: ";
    cin>>number;
    cout<<endl;
    
    if(!((number >= 1000) && (number <= 3000))){
        cout<<"Please enter a number that is between 1000 and 3000, not "
                <<number<<endl;
        exit(EXIT_FAILURE);
    }
    
    //Process/Calculations Here
    nThsnds = number/THSND;
    number %= THSND;
    
    nHundrds = number/HNDRD;
    number %= HNDRD;
    
    nTens = number / TENS;
    number %= TENS;
    
    nOnes = number;//Number already set to ones because of formatting
    
    //Output Located Here
    
    //Display the number of thousands
    switch(nThsnds){
        case 3: cout<<"M";
        case 2: cout<<"M";
        case 1: cout<<"M";
    }
    
    //Display number of hundreds
    switch(nHundrds){
        case 9: cout<<"CM";break;
        case 8: cout<<"DCCC";break;
        case 7: cout<<"DCC";break;
        case 6: cout<<"DC";break;
        case 5: cout<<"C";break;
        case 4: cout<<"CD";break;
        case 3: cout<<"C";
        case 2: cout<<"C";
        case 1: cout<<"C";
    }
    
    //Display number of tens
    switch(nTens){
        case 9: cout<<"XC";break;
        case 8: cout<<"LXXX";break;
        case 7: cout<<"LXX";break;
        case 6: cout<<"LX";break;
        case 5: cout<<"L";break;
        case 4: cout<<"XL";break;
        case 3: cout<<"X";
        case 2: cout<<"X";
        case 1: cout<<"X";
    }
    
    //Display number of ones
    switch(nOnes){
        case 9: cout<<"IX";break;
        case 8: cout<<"VIII";break;
        case 7: cout<<"VII";break;
        case 6: cout<<"VI";break;
        case 5: cout<<"V";break;
        case 4: cout<<"IV";break;
        case 3: cout<<"I";
        case 2: cout<<"I";
        case 1: cout<<"I";
    }
    
    //Exit
    return 0;
}

