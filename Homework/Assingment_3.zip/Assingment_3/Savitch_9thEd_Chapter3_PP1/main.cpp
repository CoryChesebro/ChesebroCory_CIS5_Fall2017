
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on October 10 2017 5:56 PM
 * Purpose: Long Distance Calls (Savitch Project 1)
 */

//System libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float MTF68 = 0.40f;//Monday through Friday 8 am to 6 pm, 40 cents per min
const float MTF86 = 0.25f;//Monday through Friday 6 pm to 8 am, 25 cents per min
const float STS = 0.15f;//Saturday through Sunday any time, 15 cents per min

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    char day;
    short min, time;
    float total;//Total is less than time because multiplying by a num <1 so short is big enough
    
    //Process mapping from inputs to outputs
    cout<<"This program finds the total of your long distance call."<<endl;
    cout<<"To find out what your long distance call costs, input the day, time"
            " of day, and duration of the call in minutes."<<endl;
    cout<<endl;
    
    //Get user input / Data
    cout<<"An example input looks like: M(day) 14(hour of the day the call took "
            "place in 24hr format) 40(duration of call in minutes. > M 14 40"
            <<endl;
    cout<<endl;
    
    cout<<"Please enter your input here all on one line: ";
    cin>>day>>time>>min;
    cout<<endl;
    
    //Re-Display inputs / Display outputs 
    cout<<fixed<<setprecision(2);//Making realistic money outputs
    
    switch(day){//The ternary statement used doesn't account for errors in time input
        
        case 'M':
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Monday and cost: $"<<total<<endl;
            break;
            
        case 'm': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Monday and cost: $"<<total<<endl;
            break;
            
        case 'T': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Tuesday or Thursday and cost: $"<<total<<endl;
            break;
            
        case 't': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Tuesday or Thursday and cost: $"<<total<<endl;
            break;
            
        case 'W': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Wednesday and cost: $"<<total<<endl;
            break;
        
        case 'w': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Wednesday and cost: $"<<total<<endl;
            break;
        
        case 'F': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Friday and cost: $"<<total<<endl;
            break;
           
        case 'f': 
            (time >= 6 && time <= 8)?(total = min * MTF68):(total = min * MTF86);
            cout<<"This call was made on a Friday and cost: $"<<total<<endl;
            break;
        
        case 'S': 
            total = min * STS;//Because time doesn't matter on the weekends apparently
            cout<<"This call was made on a Saturday or Sunday and cost: $"<<total<<endl;
            break;
        
        case 'S': 
            total = min * STS;//Because time doesn't matter on the weekends apparently
            cout<<"This call was made on a Saturday or Sunday and cost: $"<<total<<endl;
            break;
            
    }
    
    //Exit to function main / End program
    return 0;
}

