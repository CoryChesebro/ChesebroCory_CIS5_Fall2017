
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 1, 2017, 10:01 PM
 * Purpose: Savitch Chapter 2 Programming Project 2
 */

//System libraries
#include <iostream>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const int payInc = 1076; //What to multiply by to get the new pay rate

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    unsigned short oldPay; //I mean I don't think anyone using this makes more than 65k a month but who knows
    unsigned short newDollars;
    unsigned short newCents;
    unsigned int newPay;
    
    
    //Variable Initialization 
    
    //Process mapping from inputs to outputs
    cout<<"This program takes your old monthly pay and gives you your new pay"
            " following the pay increase."<<endl;
    
    //Get user input / Data
  do{
    cout<<endl; //Just to make things look neater
    
    cout<<"Please enter your previous monthly pay or enter 0 to end the program: ";
    cin>>oldPay;
    cout<<endl;
    
    //Re-Display inputs / Display outputs 
    if (oldPay > 0){ //Only works if monthly pay is less than ***65000***
        newPay = oldPay * payInc;
        newDollars = newPay / 1000;//Getting dollar amount to reduce inaccuracy
        newCents = (newPay / 10) % 100;//Getting cent "                        " 
        
        cout<<"Your new monthly pay is: $"<<newDollars<<"."<<newCents<<" per month."<<endl;
        }
    } while(oldPay > 0);
    
    //Exit to function main / End program
    return 0;
}