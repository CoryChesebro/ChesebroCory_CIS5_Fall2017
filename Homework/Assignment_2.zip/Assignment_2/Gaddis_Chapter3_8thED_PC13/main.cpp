
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 
 * Purpose: Celsius to Fahrenheit
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float USD2YEN = 112.47;
const float USD2EUR = 0.85;

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float usd;
    float cYen, cEur;//Converted yen, converted euro
    
    //Variable Initialization
    
    //Process mapping from inputs to outputs
    cout<<"This program will convert your amount of USD to Yen and Euros"<<endl;
    
    //Get user input / Data
    cout<<"Enter how many US Dollars to the nearest cent you have: ";
    cin>>usd;
    cout<<endl;
    
    //Re-Display inputs / Display outputs
    cYen = USD2YEN * usd;
    cEur = USD2EUR * usd;
    
    cout<<fixed<<setprecision(2)<<endl;
    cout<<"$"<<usd<<" is "<<cYen<<" Yen and, "<<cEur<<" Euros."<<endl;
    
    //Exit to function main / End program
    return 0;
}

