
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 1, 2017, 1:39 PM
 * Purpose: Savitch Chapter 2 Programming Project 1
 */

//System libraries
#include <iostream>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float sweet = 0.35; //Grams of sweetener per soda can
const short gpp = 454; //Conversion for grams per pound 
const float lethal = 0.1428; //Lethal dosage per gram body weight (5/35)

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    int weight;
    int weightG; //Weight in grams
    int dosage;
    int numCans; //Number of cans able to be consumed
    string input;
    
    //Variable Initialization 
    input = "y";
    
    //Process mapping from inputs to outputs
    cout<<"This program will take your weight in pounds and determines "
          "the lethal dosage of artificial sweetener found in diet soda."<<endl;
    cout<<endl;
    
    //Get user input / Data
    do{
    cout<<"What is your goal weight in pounds?: ";
    cin>>weight;
    cout<<endl;

    //Re-Display inputs / Display outputs 
    weightG = weight * gpp;
    dosage = weightG * lethal;
    numCans = dosage / sweet;
    
    cout<<"For your weight, the lethal dosage of artificial sweetener is "<<
            dosage<<" grams which means you can have "<<numCans<<
                " cans of soda."<<endl;
    cout<<endl;
    
    cout<<"Would you like to input another weight? Enter y to continue: ";
    cin>>input;
    cout<<endl;
    
    } while (input == "y" || input == "Y");
    
    //Exit to function main / End program
    return 0;
}

