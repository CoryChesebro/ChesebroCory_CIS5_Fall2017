
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 
 * Purpose: How many calories?
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const char CKCAL = 10;

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    short cEaten;//Cookies eaten
    int totCal;//Total calories (using int because when multiplying its good to upgrade the resultant variable)
    
    //Variable Initialization
    
    //Process mapping from inputs to outputs
    cout<<"This program will calculate how many calories consumed based of of"
            " how many cookies eaten"<<endl;
    
    //Get user input / Data
    cout<<"Please enter how many cookies you ate: ";
    cin>>cEaten;
    cout<<endl;
    
    //Re-Display inputs / Display outputs
    totCal = CKCAL * cEaten;
    
    cout<<"You consumed "<<totCal<<" calories by eating "<<cEaten<<" cookies.";
    
    //Exit to function main / End program
    return 0;
}

