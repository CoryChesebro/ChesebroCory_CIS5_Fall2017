
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 
 * Purpose: Celsius to Fahrenheit
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float c;//Celsius 
    float f;//Fahrenheit
    
    //Variable Initialization
    
    //Process mapping from inputs to outputs
    cout<<"This program will convert Celsius to Fahrenheit"<<endl;
    
    //Get user input / Data
    cout<<"Input the temperature in Celsius: ";
    cin>>c;
    cout<<endl;
    
    //Re-Display inputs / Display outputs
    f = 1.8 * c + 32;//Used decimal form of 9/5 or else it wouldn't work
    
    cout<<"The temperature in Fahrenheit is "<<f<<" degrees"<<endl;
    
    //Exit to function main / End program
    return 0;
}

