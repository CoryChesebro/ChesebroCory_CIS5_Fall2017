
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 
 * Purpose: Test Average
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {//This code doesnt work and im not sure why, it seems to skip cins and just move to the next one

    //Variable Declaration
    char test1, test2, test3, test4, test5;
    float avg;
    //Variable Initialization
    
    //Process mapping from inputs to outputs

    //Get user input / Data
    cout<<"Please enter 5 test scores to get the average"<<endl;
    
    cout<<"Please enter test 1 score: ";
    cin>>test1;
    cout<<endl;
    
    cout<<"Please enter test 2 score: ";
    cin>>test2;
    cout<<endl;
    
    cout<<"Please enter test 3 score: ";
    cin>>test3;
    cout<<endl;
    
    cout<<"Please enter test 4 score: ";
    cin>>test4;
    cout<<endl;
    
    cout<<"Please enter test 5 score ";
    cin>>test5;
    cout<<endl;
    
    avg = (test1 + test2 + test3 + test4 + test4 + test5) / 5;
    
    //Re-Display inputs / Display outputs
    cout<<setprecision(1)<<fixed<<"The average is: "<<avg<<endl;
    //Exit to function main / End program
    return 0;
}

