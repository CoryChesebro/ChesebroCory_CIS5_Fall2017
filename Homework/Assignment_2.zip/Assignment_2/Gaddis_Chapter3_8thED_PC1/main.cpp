
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 PM
 * Purpose: Mileage
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    short gallons;
    short miles;
    float mpg;
    //Variable Initialization 
    
    //Process mapping from inputs to outputs
    cout<<"This program will calculate your milage based off of your miles driven"
            " and how many gallons of gas consumed."<<endl;
    
    //Get user input / Data
    cout<<"Enter how many miles you have driven: ";
    cin>>miles;
    cout<<endl;
    
    cout<<"Enter how many gallons consumed in those miles driven: ";
    cin>>gallons;
    cout<<endl;
    
    mpg = miles/gallons;
    
    //Re-Display inputs / Display outputs 
    cout<<"Your car gets "<<mpg<<" miles per gallon"<<endl;
    
    //Exit to function main / End program
    return 0;
}

