
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 
 * Purpose: Male and Female percentages
 */

//System libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    short males, females, total;
    float pcntM, pcntF;//Percent Males, Percent Females
    
    //Variable Initialization
    
    //Process mapping from inputs to outputs
    cout<<"This program will calculate the percent of males and females per "
            "class"<<endl;
    
    //Get user input / Data
    cout<<"Please enter the number of males: ";
    cin>>males;
    cout<<endl;
    
    cout<<"Please enter the number of females: ";
    cin>>females;
    cout<<endl;
    
    //Re-Display inputs / Display outputs
    total = males + females;
    cout<<total;
    pcntM = males / (static_cast<float>(total)) * 100;
    pcntF = (females / static_cast<float>(total)) * 100;
    
    cout<<fixed<<setprecision(1)<<endl;
    cout<<"The percentage of males in the class is "<<pcntM<<"%"<<endl;
    cout<<"The percentage of females in the class is "<<pcntF<<"%"<<endl;
    
    //Exit to function main / End program
    return 0;
}

