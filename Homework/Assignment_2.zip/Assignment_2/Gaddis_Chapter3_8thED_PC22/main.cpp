
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 24, 2017 
 * Purpose: Angle Calculator
 */

//System libraries
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float rad;
    
    //Variable Initialization
    
    //Process mapping from inputs to outputs
    cout<<"This program will give you the sine, cosine, and tangent of the radian"
            " value that you enter."<<endl;
    
    //Get user input / Data
    cout<<"Please enter a radian value: ";
    cin>>rad;
    cout<<endl;//The reason i do this is to create space between the input and the next line
    
    //Re-Display inputs / Display outputs
    cout<<fixed<<setprecision(4)<<endl;
    cout<<"Sine: "<<sin(rad)<<endl;
    cout<<"Cosine: "<<cos(rad)<<endl;
    cout<<"Tangent: "<<tan(rad)<<endl;
    
    //Exit to function main / End program
    return 0;
}

