
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 16, 2017
 * Purpose: Sales tax
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float STAX = 0.04;//State Sales tax
const float CTAX = 0.02;//County Sales tax

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    char purTot;//Purchase total
    float postTot;//Total after taxes
    
    //Variable Initialization 
    purTot = 95;//Dollars
    postTot = purTot * (1 + STAX + CTAX);
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"The total after taxes for a $95 purchase is: "<<postTot<<endl;
    
    //Exit to function main / End program 
    return 0;
}