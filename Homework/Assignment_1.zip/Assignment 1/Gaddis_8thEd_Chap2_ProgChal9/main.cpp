/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 17, 2017
 * Purpose: Total Purchase
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY


//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    
    //Variable Initialization 

    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"Size of char: "<<sizeof(char)<<endl;
    cout<<"Size of int: "<<sizeof(int)<<endl;
    cout<<"Size of float: "<<sizeof(float)<<endl;
    cout<<"Size of double: "<<sizeof(double)<<endl;
    
    //Exit to function main / End program 
    return 0;
}