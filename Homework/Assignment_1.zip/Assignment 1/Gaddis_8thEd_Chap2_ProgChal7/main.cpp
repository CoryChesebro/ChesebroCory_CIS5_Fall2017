/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 17, 2017
 * Purpose: Ocean Levels
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float OCEAN = 1.5;//Levels in millimeters that the ocean rises

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float year5, year7, year10;
    
    //Variable Initialization 
    year5 = 5 * OCEAN;
    year7 = 7 * OCEAN;
    year10 = 10 * OCEAN;
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"Ocean level in 5 years: "<<year5<<" mm"<<endl;
    cout<<"Ocean level in 7 years: "<<year7<<" mm"<<endl;
    cout<<"Ocean level in 10 years: "<<year10<<" mm"<<endl;
    
    //Exit to function main / End program 
    return 0;
}