/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 17, 2017
 * Purpose: Annual Pay
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const short PAYAMT = 2200;//Amount payed per period
const char PAYPER = 26;//How many pay periods

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    int annPay;//Annual pay
    
    //Variable Initialization 
    annPay = PAYAMT * PAYPER;
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"Total annual pay is : $"<<annPay<<endl;
    
    //Exit to function main / End program 
    return 0;
}