/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 17, 2017
 * Purpose: Total Purchase
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float TAX = 1.07;//Sales tax

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float item1, item2, item3, item4, item5;
    float total_1, total2, total3, total4, total5;
    
    //Variable Initialization 
    item1 = 15.95;
    item2 = 24.95;
    item3 = 6.95;
    item4 = 12.95;
    item5 = 3.95;
    
    total_1 = item1 * TAX;
    total2 = item2 * TAX;
    total3 = item3 * TAX;
    total4 = item4 * TAX;
    total5 = item5 * TAX;
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout.precision(4);//Sets the number of sig figs to print
    cout<<"The subtotal for item 1 is, $"<<item1<<" the total after tax is $"
            <<total_1<<" and the percent tax is 7%"<<endl;
    
    cout<<"The subtotal for item 2 is, $"<<item2<<" the total after tax is $"
            <<total2<<" and the percent tax is 7%"<<endl;
    
    cout.precision(3);
    cout<<"The subtotal for item 3 is, $"<<item3<<" the total after tax is $"
            <<total3<<" and the percent tax is 7%"<<endl;
    
    cout.precision(4);
    cout<<"The subtotal for item 4 is, $"<<item4<<" the total after tax is $"
            <<total4<<" and the percent tax is 7%"<<endl;
    
    cout.precision(3);
    cout<<"The subtotal for item 5 is, $"<<item5<<" the total after tax is $"
            <<total5<<" and the percent tax is 7%"<<endl;
            
    //Exit to function main / End program 
    return 0;
}