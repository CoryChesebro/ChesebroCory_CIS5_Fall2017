
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 16, 2017
 * Purpose: Sales Prediction
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float PCTS = 0.58; //Percent of total sales
//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float totSale;//Total sales for the company
    float westCS;//West Coast Sales
    
    //Variable Initialization 
    totSale = 8.6;//Million dollars
    westCS = totSale * PCTS;
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"The total sales for the west coast division were: "<<westCS<<
            " million dollars"<<endl;
    //Exit to function main / End program
    return 0;
}

