
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 16, 2017
 * Purpose: Sum of two numbers
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    unsigned char a,b,total;
    
    //Variable Initialization 
    a = 50; //This program is stupid
    b = 100; //But so are the Savitch Chapter 1 problems
    total = a + b; //Please give us a project soon :( 
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    
    //Exit to function main / End program
    return 0;
}

