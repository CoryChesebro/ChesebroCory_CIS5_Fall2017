
/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 16, 2017
 * Purpose: Average of numbers
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY
const float TAX = 0.0675;//Tax percentage
const float TIP = 0.2;//Tip percentage

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    float mealAmt, mealTot, totBill, tipTot;//Price of food, price including tax, bill total after tip and tax, tip total alone
    
    //Variable Initialization 
    mealAmt = 88.67;
    mealTot = mealAmt * (1 + TAX);
    tipTot = mealTot * TIP;
    totBill = mealTot + tipTot;
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"For a meal costing $88.67, the meal amount plus tax is $"<<mealTot<<
            " , the tip total is $"<<tipTot<<" , the total bill is $"<<totBill<<endl;
    //Exit to function main / End program 
    return 0;
}