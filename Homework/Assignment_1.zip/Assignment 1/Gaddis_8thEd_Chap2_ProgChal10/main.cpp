/* 
 * File:   main.cpp
 * Author: Cory Chesebro
 * Created on September 17, 2017
 * Purpose: Total Purchase
 */

//System libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants - Physics/Math/Conversions ONLY

//Function prototypes

//Execution begins here - DEATH PENALTY
int main() {
    //Variable Declaration
    
    //Variable Initialization 
    
    //Process mapping from inputs to outputs
    
    //Re-Display inputs / Display outputs 
    cout<<"A car that holds 15 gallons and can drive 375 miles gets "
            <<375/15<<" miles per gallon"<<endl;
    //Exit to function main / End program 
    return 0;
}